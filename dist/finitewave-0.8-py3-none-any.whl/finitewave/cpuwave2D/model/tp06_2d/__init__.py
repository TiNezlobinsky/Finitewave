from finitewave.cpuwave2D.model.tp06_2d.tp06_2d import TP062D
