

class Stim:

    def __init__(self, time):
        self.t = time
        self.passed = False

    def stimulate(self, model):
        pass

    def ready(self):
        pass

    def done(self):
        pass
