

class Command:
    def __init__(self, time):
        self.t = time
        self.passed = False

    def execute(self, model):
        pass
