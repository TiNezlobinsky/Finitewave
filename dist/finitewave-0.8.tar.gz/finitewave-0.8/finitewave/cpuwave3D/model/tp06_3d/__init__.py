from finitewave.cpuwave3D.model.tp06_3d.tp06_3d import TP063D
